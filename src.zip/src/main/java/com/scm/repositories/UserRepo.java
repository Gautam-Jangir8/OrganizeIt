package com.scm.repositories;

import com.scm.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepo extends JpaRepository<User, String> {
    // Extra methods for db related operations
    // Custom query methods, custom finder method

    Optional<User> findByEmail(String email); // It's implementation will be provided by Spring JPA

    Optional<User> findByEmailAndPassword(String email, String password);
}
