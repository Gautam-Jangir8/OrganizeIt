package com.scm.helpers;

public enum MessageType {
    blue, red, green, yellow
}
