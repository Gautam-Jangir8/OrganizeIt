package com.scm.helpers;

import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;

public class Helper {

    public static String getEmailOfLoggedInUser(Authentication authentication) {

        if (authentication instanceof OAuth2AuthenticationToken) {
            // Converting Authentication to OAuth2AuthentictaionToken
            var aOAuth2AuthenticationToken = (OAuth2AuthenticationToken) authentication;
            var clientId = aOAuth2AuthenticationToken.getAuthorizedClientRegistrationId();

            var oAuth2User = (OAuth2User)authentication.getPrincipal();
            String username = "";
            // Agar hamne sigin with with google kiya hai to: email kaisa nikalanga
            if (clientId.equalsIgnoreCase("google")) {
                System.out.println("getting email from google");
                username = oAuth2User.getAttribute("email").toString();
            } else if (clientId.equalsIgnoreCase("github")) { // Agar hamne github sa login kiya hai to: email kaisa nikalanga
                System.out.println("getting email from github");
                username = oAuth2User.getAttribute("email") != null ? oAuth2User.getAttribute("login").toString() : oAuth2User.getAttribute("login").toString() + "@gmail.com";
            }

            return username;
        } else {
            // Agar hamna email ya password sa login kiya hai to: email kaisa nikalanga
            System.out.println("getting data from local database");
            return authentication.getName();
        }
    }
}
