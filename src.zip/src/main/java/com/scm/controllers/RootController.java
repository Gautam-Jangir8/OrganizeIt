package com.scm.controllers;

import com.scm.entities.User;
import com.scm.helpers.Helper;
import com.scm.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class RootController {

    Logger logger = LoggerFactory.getLogger(RootController.class);
    @Autowired
    private UserService userService;

    // Add loggedInUser information
    @ModelAttribute
    public void addLoggedInUserInformation(Model model, Authentication authentication) {
        // If aap Authenticated hi nahi ho
        if(authentication==null) {
            return;
        }

        String username = Helper.getEmailOfLoggedInUser(authentication);
        logger.info("user profile: " + username);

        // username hi email hai (Jaisa gangadhar hi shaktiman hai)
        User user = userService.getUserByEmail(username);
        System.out.println("user profile: " + user);

        System.out.println(user.getName());
        System.out.println(user.getEmail());
        model.addAttribute("loggedInUser", user);
    }
}
