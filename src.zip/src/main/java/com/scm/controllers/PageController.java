package com.scm.controllers;

import com.scm.entities.User;
import com.scm.forms.UserForm;
import com.scm.helpers.Message;
import com.scm.helpers.MessageType;
import com.scm.services.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PageController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String index() {
        return "redirect:/home";
    }

    // home
    @RequestMapping("/home")
    public String home(Model model) {
        System.out.println("Home Page Handler");

        // Sending data to view
        model.addAttribute("name", "Gautam Jangir");
        model.addAttribute("youtubeChannel", "LearnCodeWithGautam");
        model.addAttribute("githubRepo", "https://github.com/Gautam-Jangir8/LeetCode-Questions");
        return "home";
    }

    // about
    @RequestMapping("/about")
    public String aboutPage() {
        System.out.println("About Page Handler");
        return "about";
    }

    // services
    @RequestMapping("/services")
    public String servicesPage() {
        System.out.println("Services Page Handler");
        return "services";
    }

    // contact
    @RequestMapping("/contact")
    public String contactPage() {
        System.out.println("Contact Page Handler");
        return "contact";
    }

    // This is showinng login page
    @RequestMapping("/login")
    public String loginPage() {
        System.out.println("login Page Handler");
        return "login";
    }

    // This is Registration page
    @RequestMapping("/register")
    public String registerPage(Model model) {
        System.out.println("register Page Handler");
        UserForm userForm = new UserForm();
        model.addAttribute("userForm", userForm);
        return "register";
    }

    // Processing register
    @RequestMapping(value = "/do-register", method = RequestMethod.POST)
    public String processRegister(@Valid @ModelAttribute UserForm userForm, BindingResult rBindingResult, HttpSession session) {
        System.out.println("do-register Page Handler");
        // fetch the data --> Validate the data --> Save to database --> Successful Message --> redirect
        System.out.println(userForm);

        // Validate the user
        if(rBindingResult.hasErrors()) {
            return "register";
        }

        // Save to database
        // UserForm --> User
        //        User user = User.builder()
        //                .name(userForm.getName())
        //                .password(userForm.getPassword())
        //                .email(userForm.getEmail())
        //                .about(userForm.getAbout())
        //                .phoneNumber(userForm.getPhoneNumber())
        //                .profilePic("https://www.google.com/search?q=default+profile+picture&oq=default+profile+picture&gs_lcrp=EgZjaHJvbWUyDAgAEEUYORixAxiABDIHCAEQABiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIHCAYQABiABDIHCAcQABiABDIHCAgQABiABDIHCAkQABiABNIBCDY0MTJqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#vhid=mFBeEI-GK2RjoM&vssid=l")
        //                .build();
        // OR
        User user = new User();
        user.setName(userForm.getName());
        user.setEmail(userForm.getEmail());
        user.setPassword(userForm.getPassword());
        user.setAbout(userForm.getAbout());
        user.setPhoneNumber(user.getPhoneNumber());
        user.setProfilePic("https://www.google.com/search?q=default+profile+picture&oq=default+profile+picture&gs_lcrp=EgZjaHJvbWUyDAgAEEUYORixAxiABDIHCAEQABiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIHCAYQABiABDIHCAcQABiABDIHCAgQABiABDIHCAkQABiABNIBCDY0MTJqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#vhid=mFBeEI-GK2RjoM&vssid=l");

        User savedUser = userService.saveUser(user);
        System.out.println("user Saved");

        // Add the message for Successful signup only
        Message message = Message.builder()
                .content("Registration Successful")
                .type(MessageType.green)
                .build();

        session.setAttribute("message", message);

        return "redirect:/register";
    }
}
