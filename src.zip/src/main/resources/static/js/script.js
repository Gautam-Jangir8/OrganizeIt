console.log("Script Loaded");

// Change Theme Work
let currentTheme = getTheme();// Now fetch the current theme form the local storage
// Initially it will run (Now change theme will be only called initially when the content is loaded)
document.addEventListener('DOMContentLoaded', () => {
    changeTheme();
})

//tobedone
function changeTheme() {
    // Setting the theme to web-page
    changePageTheme(currentTheme, "")

    // Set the listener to Toggle Theme button
    const changeThemeButton = document.querySelector('#theme_change_button');

    changeThemeButton.addEventListener("click", (event) => {
        let oldTheme = currentTheme;
        console.log("Change Theme Button Clicked");

        if (currentTheme === "dark") {
            // Set theme to light
            currentTheme = "light"
        } else {
            // Set theme to dark
            currentTheme = "dark"
        }

        console.log(currentTheme);
        changePageTheme(currentTheme, oldTheme);
    })
}

// Set theme to local storage
function setTheme(theme) {
    localStorage.setItem("theme", theme);
}

// Get theme from local storage
function getTheme() {
    let theme = localStorage.getItem("theme");

    return theme ? theme : "light";
}

// Change current page theme
function changePageTheme(theme, oldTheme) {
    // (Update theme in local storage) Update the local storage for the changed theme value
    setTheme(currentTheme);
    // (Remove the current theme) Remove the set Theme of web-page from html class

    // (Set the current theme) Now we have to add new theme to web-page in that html file we have to set the class of theme
    document.querySelector('html').classList.add(theme);
    if(oldTheme) {
        document.querySelector('html').classList.remove(oldTheme);
    }
    // Change the text of button (light <-> dark)
    document.querySelector('#theme_change_button').querySelector('span').textContent = theme == "light" ? "Dark" : "Light";
}
// End Change Theme Work
// ---------------------------------------------------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', function() {
    const hamburgerButton = document.getElementById('hamburger-btn-user');
    const navbarMenu = document.getElementById('navbar-cta-btn-user');
    const hamburgerMenu = document.getElementById('hamburger-btn-user');

    hamburgerButton.addEventListener('click', function (){
        navbarMenu.classList.toggle('hidden');
        hamburgerButton.classList.toggle('hidden');
    });
});